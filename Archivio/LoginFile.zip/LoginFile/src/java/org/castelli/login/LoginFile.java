/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.castelli.login;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author Castelli
 */
@WebService(serviceName = "LoginFile")
public class LoginFile {

    /**
     * Web service operation
     */
    final String percorsoFile=""; //per ogni riga user,passsword,
    @WebMethod(operationName = "login")
    public int login(@WebParam(name = "username") String username, @WebParam(name = "password") String password) throws FileNotFoundException, IOException {
        //TODO write your implementation code here:
        String user="";
        String psw="";
        try (BufferedReader bufferLettura = new BufferedReader(new FileReader(percorsoFile))) {
            String riga="";
            while((riga=bufferLettura.readLine())!=null){
                    user=riga.split(",")[0];
                    psw=riga.split(",")[1];
                if(username.equals(user)){
                    if(password.equals(psw)){
                        return 1; //giusta
                    }
                    return 2;   //password sbagliata
                }
        }
    }
    return 3; //utente non trovato
    }
}
