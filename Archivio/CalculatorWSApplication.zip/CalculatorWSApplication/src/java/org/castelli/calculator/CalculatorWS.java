/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.castelli.calculator;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author castelli_elisa
 */
@WebService(serviceName = "CalculatorWS")
public class CalculatorWS {


    /**
     * Web service operation
     */
    @WebMethod(operationName = "somma")
    public int somma(@WebParam(name = "num1")
            int num1, @WebParam(name = "num2") 
                    int num2) {
        //TODO write your implementation code here:
        int ris= num1+num2;
        return ris;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "login")
    public int login(@WebParam(name = "user") 
            String user, @WebParam(name = "password")
                    String password) {
        //TODO write your implementation code here:
        String username="user";
        String psw="password";
        if(user.equals(username)){
            if(psw.equals(password)){
                return 1; //giusta
            }
            return 2;   //password sbagliata
        }
        else{
            return 3; //username non registrato
        }
    }
}
