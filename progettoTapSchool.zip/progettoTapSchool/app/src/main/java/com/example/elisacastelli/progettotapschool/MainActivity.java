package com.example.elisacastelli.progettotapschool;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button buttonAggiungi=(Button)findViewById(R.id.buttonAggiungi2);
        buttonAggiungi.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View arg0) {
                // definisco l'intenzione
                Intent inserisci = new Intent(MainActivity.this,ActivityInserimento.class);
                // passo all'attivazione dell'activity Pagina.java
                startActivity(inserisci);
            }
        });

       /*
            Button buttonModifica=(Button)findViewById(R.id.buttonModifica);
            buttonModifica.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View arg0) {
                    // definisco l'intenzione
                    Intent modifica = new Intent(MainActivity.this,ActivityModificaAttivita.class);
                    // passo all'attivazione dell'activity Pagina.java
                    startActivity(modifica);
                }
            });
        */

        /*Button buttonElimina=(Button)findViewById(R.id.buttonElimina);
        buttonElimina.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View arg0) {
                // definisco l'intenzione
                Intent elimina = new Intent(MainActivity.this,ActivityEliminazioneAttivita.class);
                // passo all'attivazione dell'activity Pagina.java
                startActivity(elimina);
            }
        });*/
    }
}

