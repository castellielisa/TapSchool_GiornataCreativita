/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package consumerperformances;

import java.util.Scanner;

/**
 *
 * @author Matteo Panzeri
 */
public class ConsumerPerformances {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
    private static void eliminaPerformance()
     {
        Scanner tastiera = new Scanner(System.in);   
        System.out.print("Inserisci nome della performance da eliminare: ");
        String performance = tastiera.nextLine();        
        elimina(performance);
    }
    private static boolean elimina(java.lang.String performance) {
        org.me.serviceTapSchool service = new org.me.serviceTapSchool();
        org.me.serviceTapSchool port = service.serviceTapSchool();
        return port.cancellazionePerformance(performance);
    }
    
}
