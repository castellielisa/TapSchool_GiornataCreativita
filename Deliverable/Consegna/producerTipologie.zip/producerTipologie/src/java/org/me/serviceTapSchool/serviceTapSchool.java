/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.me.serviceTapSchool;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author Matteo Panzeri
 */
@WebService(serviceName = "serviceTapSchool")
public class serviceTapSchool {

    String filePath = "tipologie.txt";
    @WebMethod(operationName = "hello")
    public String hello(@WebParam(name = "name") String txt) {
        return "Hello " + txt + " !";
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "aggiungiTipologia")
    public boolean aggiungiTipologia(@WebParam(name = "nome") String nome, @WebParam(name = "descrizione") String descrizione) {
        String tipologia = nome + ";" + descrizione+"\n";
        BufferedWriter bufferWriter = null;
        FileWriter fileWriter = null;

        try{
            fileWriter = new FileWriter(filePath, true);
            bufferWriter = new BufferedWriter(fileWriter);
            bufferWriter.write(tipologia);
            
            bufferWriter.close();
            fileWriter.close();
            return true;
        } catch (IOException e) {
            return false;
        }
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "modificaTipologia")
    public boolean modificaTipologia(@WebParam(name = "nomeTipologia") String nomeTipologia, @WebParam(name = "VecchiaDescrizione") String VecchiaDescrizione, @WebParam(name = "NuovaDescrizione") String NuovaDescrizione) throws FileNotFoundException, IOException {
                FileReader reader = new FileReader("tipologie.txt");
                BufferedReader bufferReader = new BufferedReader(reader);
		String linea;
                bufferReader = new BufferedReader(new FileReader("tipologie.txt"));
                List<String> tipologie=new ArrayList<String>();
               FileWriter fileWriter = new FileWriter(filePath, true);
               BufferedWriter bufferWriter = new BufferedWriter(fileWriter);
                 
		while ((linea = bufferReader.readLine()) != null) {
                   
                    String [] tipo=linea.split(";");                    
                    if (! tipo[0].equals(nomeTipologia) ) {
			 tipologie.add(linea);
                    }
                }
                 bufferWriter.write(nomeTipologia + ";" + NuovaDescrizione+"\n");
                for(int i=0;i<tipologie.size();i++)
                    bufferWriter.write(tipologie.get(i));                            
                
                return true;
                
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "cancellazionePerformance")
    public boolean cancellazionePerformance(@WebParam(name = "nomePerformance") String nomePerformance) throws FileNotFoundException, IOException {
       FileReader reader = new FileReader("performance.txt");
                BufferedReader bufferReader = new BufferedReader(reader);
		String linea;
                bufferReader = new BufferedReader(new FileReader("performance.txt"));
                List<String> tipologie=new ArrayList<String>();
               FileWriter fileWriter = new FileWriter(filePath, true);
               BufferedWriter bufferWriter = new BufferedWriter(fileWriter);
                 
		while ((linea = bufferReader.readLine()) != null) {
                   
                    String [] tipo=linea.split(";");                    
                    if (! tipo[0].equals(nomePerformance) ) {
			 tipologie.add(linea);
                    }
                }
                
                for(int i=0;i<tipologie.size();i++)
                    bufferWriter.write(tipologie.get(i));                            
                
                return true;
    }
}
