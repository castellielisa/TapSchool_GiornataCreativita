/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package login_consumer;

import java.util.Scanner;

/**
 *
 * @author Castelli
 */
public class Login_Consumer {

    /**
     * @param args the command line arguments
     */
     public static void main(String[] args) {
        Scanner tastiera = new Scanner(System.in);
        
       
        System.out.print("Inserisci username: ");
        String username = tastiera.nextLine();
        System.out.print("Inserisci password: ");
        String password = tastiera.nextLine();
        
        System.out.println();
        System.out.println(login(username,password));
    }

    private static String login(java.lang.String username, java.lang.String password) {
        org.tapSchool.gestioneAccessi service = new org.tapSchool.gestioneAccessi();
        org.org.tapSchool.gestioneAccessi port = service.getgestioneAccessiPort();
        return port.login(username, password);
    }
    
}
    
}
