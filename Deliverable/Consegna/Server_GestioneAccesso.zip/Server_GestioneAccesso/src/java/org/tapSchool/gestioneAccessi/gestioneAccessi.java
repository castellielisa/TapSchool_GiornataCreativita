/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.tapSchool.gestioneAccessi;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author Castelli
 */
@WebService(serviceName = "gestioneAccessi")
public class gestioneAccessi {

    /**
     * Web service operation
     */
    final String percorsoFile=""; //per ogni riga user,passsword,
    @WebMethod(operationName = "login")
    public int login(@WebParam(name = "username") String username, @WebParam(name = "password") String password)throws FileNotFoundException, IOException {
        //TODO write your implementation code here:
        String user="";
        String psw="";
        try (BufferedReader bufferLettura = new BufferedReader(new FileReader(percorsoFile))) {
            String riga="";
            while((riga=bufferLettura.readLine())!=null){
                    user=riga.split(",")[0];
                    psw=riga.split(",")[1];
                if(username.equals(user)){
                    if(password.equals(psw)){
                        return 1; //giusta
                    }
                    return 2;   //password sbagliata
                }
        }
    }
    return 3; //utente non trovato
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "logout")
    public boolean logout(@WebParam(name = "username") String username, 
            @WebParam(name = "Accesso") 
                    boolean Accesso) {
        //TODO write your implementation code here:
        if (Accesso == true)
        {
            Accesso = false;
        }
        return Accesso;
    }
    
    @WebMethod(operationName = "registra")
    public int registra(@WebParam(name = "Username") String username, @WebParam(name = "Password") String password, @WebParam(name = "RPassword") String RPassword) throws FileNotFoundException, IOException {
        String psw="";
        String user="";
        try (BufferedReader bufferLettura = new BufferedReader(new FileReader(percorsoFile))) {
            String riga="";
            boolean trovato=false;
            while((riga=bufferLettura.readLine())!=null && trovato==false){
                    user=riga.split(",")[0];
                    psw=riga.split(",")[1];
                if(username.equals(user)){
                        return 1; //utente già registrato
                    }
                }
        }
        if(password.equals(RPassword)){
            psw=password;
            user=username;
            FileWriter scritturaFile = new FileWriter(percorsoFile, true);
            BufferedWriter bufferScrittura = new BufferedWriter(scritturaFile);
            bufferScrittura.write(username+","+password+",");
            bufferScrittura.close();
            scritturaFile.close();
            return 0; //registrazione completata
        }
        else{
           return 2; //password ripetuta in modo sbagliato 
    }
    }
    
    @WebMethod(operationName = "resetPassword")
    public boolean resetPassword(@WebParam(name = "pswVecchia") String pswVecchia, @WebParam(name = "pswNuova") String pswNuova, @WebParam(name = "PswVecchiaSalvata") String PswVecchiaSalvata) {
        //TODO write your implementation code here:
        return pswVecchia.equals(PswVecchiaSalvata);
    }

    
        
}
