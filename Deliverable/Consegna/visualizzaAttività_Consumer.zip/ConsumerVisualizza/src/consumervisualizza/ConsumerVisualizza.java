/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package consumervisualizza;

import java.util.Scanner;

/**
 *
 * @author Castelli
 */
public class ConsumerVisualizza {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String titolo="";
        int classe=0;
        String indirizzo="";
        Scanner input = new Scanner(System.in);
        
        System.out.println("Cosa stai cercando?");
        titolo = input.nextLine();
        System.out.println("Classe interessata all'attività:");
        classe = Integer.parseInt(input.nextLine());
        System.out.println("Indirizzo di studi:");
        indirizzo = input.nextLine();
        
        String[] ris= new String[20];
        ris=visualizzaRisultati(titolo,indirizzo,classe);
        for (int i=0;i<ris.length;i++){
            System.out.println(ris[i]);
        }
    }
    final static String[] visualizzaRisultati(String titolo, String indirizzo, int anno){
        String[] risultati= new String[20];
        visualizza.visualizzaAttivita service = new visualizza.visualizzaAttivita();
        visualizza.visualizzaAttivita port = visualizza.visualizzaAttivita();
        return port.visualizza(titolo, anno, indirizzo);
        
    }
}
