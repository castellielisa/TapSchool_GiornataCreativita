/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestionetipologie;

import java.util.Scanner;

/**
 *
 * @author Matteo Panzeri
 */
public class GestioneTipologie {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    } 

     private static void aggiungiTipologia()
     {
        Scanner tastiera = new Scanner(System.in);   
        System.out.print("Inserisci nome della tipologia: ");
        String tipologia = tastiera.nextLine();
        System.out.print("Inserisci la descrizione: ");
        String descrizione = tastiera.nextLine();
        aggiungi(tipologia,descrizione);
    }
    private static boolean aggiungi(java.lang.String tipologia, java.lang.String descrizione) {
        org.me.serviceTapSchool service = new org.me.serviceTapSchool();
        org.me.serviceTapSchool port = service.serviceTapSchool();
        return port.aggiungiTipologia(tipologia, descrizione);
    }
     private static void modificaTipologia()
     {
        Scanner tastiera = new Scanner(System.in);   
        System.out.print("Inserisci nome della tipologia da modificare: ");
        String tipologia = tastiera.nextLine();
        System.out.print("Inserisci la nuova descrizione descrizione: ");
        String descrizione = tastiera.nextLine();
        modifica(tipologia,descrizione);
    }
    private static boolean modifica(java.lang.String tipologia, java.lang.String nuovaDescrizione) {
        org.me.serviceTapSchool service = new org.me.serviceTapSchool();
        org.me.serviceTapSchool port = service.serviceTapSchool();
        return port.modificaTipologia(tipologia, nuovaDescrizione);
    }
}
