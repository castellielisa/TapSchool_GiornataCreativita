/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package effettuaregistrazione;

/**
 *
 * @author mastr
 */
public class Utente {


    
    String Username;
    String Nome;
    String Cognome;
    String Mail;
    String Password;
    
    public Utente() {
        
    }

    public Utente(String Username, String Nome, String Cognome, String Mail, String Password) {
        this.Username = Username;
        this.Nome = Nome;
        this.Cognome = Cognome;
        this.Mail = Mail;
        this.Password = Password;
    }
    
    public String getUsername() {
        return Username;
    }

    public void setUsername(String Username) {
        this.Username = Username;
    }

    public String getNome() {
        return Nome;
    }

    public void setNome(String Nome) {
        this.Nome = Nome;
    }

    public String getCognome() {
        return Cognome;
    }

    public void setCognome(String Cognome) {
        this.Cognome = Cognome;
    }

    public String getMail() {
        return Mail;
    }

    public void setMail(String Mail) {
        this.Mail = Mail;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String Password) {
        this.Password = Password;
    }
    
    public boolean errori(){
        boolean errori=false;
        if("".equals(Username) || "".equals(Nome) || "".equals(Cognome) || "".equals(Mail) || Password.equals("")) 
            errori=true;
        
        if(Mail.indexOf("@")==-1) errori=true;
        
        
        return errori;
    }
}
