/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package effettuaregistrazione;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Scanner;

/**
 *
 * @author mastr
 */
public class EffettuaRegistrazione {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws ClassNotFoundException, SQLException, IOException {
        
        String Username;
        String Nome;
        String Cognome;
        String Mail;
        String Password;
        Scanner input = new Scanner(System.in);
        
        System.out.println("Inserisci username");
        Username= input.nextLine();
        System.out.println("Inserisci nome");
        Nome= input.nextLine();
        System.out.println("Inserisci cognome");
        Cognome= input.nextLine();
        System.out.println("Inserisci mail");
        Mail= input.nextLine();
        System.out.println("Inserisci password");
        Password= input.nextLine();
        
        if(registrati(Username,Nome,Cognome,Mail,Password))
            System.out.println("Registrazione avvenuta con successo!");
        else
            System.out.println("Ci sono stati problemi");
    }

    private static boolean registrati(java.lang.String arg0, java.lang.String arg1, java.lang.String arg2, java.lang.String arg3, java.lang.String arg4) {
        registrazione.Registrazione_Service service = new registrazione.Registrazione_Service();
        registrazione.Registrazione port = service.getRegistrazionePort();
        return port.registrati(arg0, arg1, arg2, arg3, arg4);
    }


    
}
