/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author mastr
 */
package effettuaregistrazione; 

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
/**
 *
 * @author mastr
 */
//import Registrazione.Utente;
import java.sql.PreparedStatement;
import javax.imageio.ImageIO;

public class gestioneDB
{
    String JDBC_DRIVER = "com.mysql.jdbc.Driver";
    String DB_URL = "jdbc:mysql://localhost/TapSchool";

    String USER = "root";
    String PASS = "";
    
    Connection conn = null;
    Statement stmt = null;
    public gestioneDB() throws ClassNotFoundException, SQLException{
        attivaConnessione();
    }
    public boolean attivaConnessione() throws ClassNotFoundException, SQLException{
       
        try{
        //STEP 2: Register JDBC driver
        Class.forName(JDBC_DRIVER);

        //STEP 3: Open a connection
        System.out.println("Connecting to a selected database...");
        conn = DriverManager.getConnection(DB_URL, USER, PASS);
        System.out.println("Connected database successfully...");

        //STEP 4: Execute a query
        System.out.println("Creating statement...");
        stmt = conn.createStatement();

        }
         catch (SQLException | ClassNotFoundException se) 
         {
             System.out.println("ciao");
        } //end try
        return true;
    }
    public boolean salvaUtente(Utente utente) throws SQLException, IOException, ClassNotFoundException
    {
       // attivaConnessione();
        String Username  = utente.getUsername();
        
        String Nome  = utente.getNome();
        
        String Cognome  = utente.getCognome();
        String Mail  = utente.getMail();
        
        String Password  =utente.getPassword();
        String sql = "INSERT INTO Utente (Username, Nome, Cognome, Mail, Password) VALUES (?, ?, ?, ?, ?)";
        PreparedStatement stmt1 = conn.prepareStatement(sql);
      
       // PreparedStatement sql1 = conn.prepareStatement("INSERT INTO Utente (Username, Nome, Cognome, Mail,Password)"     + " VALUES ("+, '"+nome+"','"+path+"', ?)");
        
       stmt1.setString(1, Username);
        
        stmt1.setString(2, Nome);
        
        stmt1.setString(3, Cognome);
        
        stmt1.setString(4, Mail);
        
        stmt1.setString(5, Password);
        
        stmt1.execute();
        try{
            conn.commit();
        }
        catch(Exception e){
            //System.out.println(e.toString());
        }
        //conn.close();
        return true;
    }
   
}
