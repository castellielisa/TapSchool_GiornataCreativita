/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Registrazione;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import Registrazione.gestioneDB;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
/**
 *
 * @author mastr
 */
@WebService(serviceName = "Registrazione")
public class Registrazione {


    



    /**
     * Web service operation
     */
    public boolean Registrati(String Username, String Nome, String Cognome, String Mail, String Password) {
        //TODO write your implementation code here:
         System.out.println("prova");
        Utente utente = new Utente(Username,Nome,Cognome,Mail,Password);
        boolean ok = false;
        try
        {
           
           gestioneDB db = new gestioneDB(); //Apro il dataBase
           if(utente.errori()==false)
           {
                byte[] bytesOfMessage = Password.getBytes("UTF-8");

                MessageDigest md = MessageDigest.getInstance("MD5");
                
                byte[] thedigest = md.digest(bytesOfMessage);
                
                String psw = thedigest.toString();
                
                utente.setPassword(psw);
               db.salvaUtente(utente);
               ok =  true;
           }
        }
        catch(Exception e)
        {
            System.out.println(e.getMessage());
        }
        
        return ok;
    }

    /**
     * Web service operation
     */
  
}
