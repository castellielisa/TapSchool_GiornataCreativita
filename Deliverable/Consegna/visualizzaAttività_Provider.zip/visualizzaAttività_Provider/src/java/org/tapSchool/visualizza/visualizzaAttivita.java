/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.tapSchool.visualizza;

import java.sql.SQLException;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author Castelli
 */
@WebService(serviceName = "visualizzaAttivita")
public class visualizzaAttivita {

    /**
     * Web service operation
     */
    @WebMethod(operationName = "visualizza")
    public String[] visualizza(@WebParam(name = "stringaDaCercare") String stringaDaCercare, @WebParam(name = "annoCorso") int annoCorso, @WebParam(name = "indirizzo") String indirizzo) throws ClassNotFoundException, SQLException {
        //TODO write your implementation code here:
        String[] attivita = new String[20];
        try
        {
           GestioneDB db = new GestioneDB(); //Apro il dataBase
           String query="SELECT attivita FROM attivita WHERE titolo LIKE '%"+stringaDaCercare+"%' AND"
                   + "annoCorso="+annoCorso+" and  indirizzo="+indirizzo;
           db.visualizzaAttivita(query);
        }catch(Exception e)
        {
            System.out.println(e.getMessage());
        }
        return attivita;
    }
}
