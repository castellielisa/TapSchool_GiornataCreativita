/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.panzeri.gestioneAccessi;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author Panzeri_Matteo
 */
@WebService(serviceName = "GestioneAccessi")
public class GestioneAccessi {


    /**
     * Web service operation
     */
    @WebMethod(operationName = "somma")
    public int somma(@WebParam(name = "num1") int num1, @WebParam(name = "num2") int num2) {
        int somma=num1+num2;
        return somma;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "registra")
    public int registra(@WebParam(name = "Username") String Username, @WebParam(name = "Password") String Password, @WebParam(name = "RPassword") String RPassword) {
        String password="";
        String username="";
        if(Password.equals(RPassword)){
            password=Password;
            username=Username;
            return 1;
        }
        return -1;
    }
}
